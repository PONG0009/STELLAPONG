#change here for your own firebase url when you have one
firebase_database='https://XXXXXXXXXXX.firebaseio.com'

source_list=[]