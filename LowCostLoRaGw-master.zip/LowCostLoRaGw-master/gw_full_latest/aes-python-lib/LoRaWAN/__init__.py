from PhyPayload import PhyPayload

def new(key):
    return PhyPayload(key)
