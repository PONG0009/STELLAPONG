#!/bin/sh

rm -rf use_loranga_internet_on_boot.txt