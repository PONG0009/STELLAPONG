# Gateway Admin

Gateway Admin is a simple responsive web interface to manage/configure some parameters of the WAZIUP's Raspberry Pi gateway.

## Installation

Go to lora_gateway/gw_web_admin folder

	> cd lora_gateway/gw_web_admin
	
Run the installation script from your RaspberryPi's shell prompt:

	> sudo ./install.sh 

The installer will complete all steps for you.

Then, use your browser, connect to the gateway's WiFi and enter the following url:

	192.168.200.1/admin

Enjoy!
M. Diop	